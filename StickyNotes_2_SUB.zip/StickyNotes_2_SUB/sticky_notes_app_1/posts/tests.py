from django.test import TestCase
from django.urls import reverse
from .models import StickyNote

# Create your tests here.


# Arrange
class StickyNoteCreateViewTests(TestCase):
    def test_create_sticky_note(self):
        # Act
        # Send a POST request to create view with form data
        response = self.client.post(
            reverse("sticky_note_create"),
            {
                "title": "Creating a Sticky Note",
                "content": "This is a test to determine the user"
                " experience",
                "is_pinned": True
            })

        # Assert
        # Retrieve the first StickyNote created in the database
        new_sticky_note = StickyNote.objects.first()

        # Confirm first StickyNote title is correct
        self.assertEqual(new_sticky_note.title, "Creating a Sticky Note")

        # Confirm first StickyNote content is correct
        self.assertEqual(
            new_sticky_note.content, "This is a test to determine the user"
            " experience")

        # Confirm exactly 1 StickyNote exists in database
        self.assertEqual(StickyNote.objects.count(), 1)

        # Confirm user is redirected back to sticky notes list page
        self.assertRedirects(
            response,
            reverse("sticky_note_list")
        )


# Arrange
class StickyNoteDeleteViewTests(TestCase):
    def test_delete_sticky_note(self):
        # Create a sticky note to be deleted
        sticky_note = StickyNote.objects.create(
            title="Deleting this sticky note",
            content="Temporary note that is to be deleted"
        )

        # Act
        # Send a POST request to the delete view
        response = self.client.post(
            reverse("sticky_note_delete", args=[sticky_note.pk]))

        # Assert
        # Confirms the sticky note has been deleted
        self.assertEqual(StickyNote.objects.count(), 0)

        # Confirm user is redirected back to sticky note list page
        self.assertRedirects(
            response,
            reverse("sticky_note_list")
        )


class StickyNoteDetailViewTests(TestCase):
    def test_detail_view_displays_note(self):
        # Arrange
        # Create a sticky note to be viewed
        specific_note = StickyNote.objects.create(
            title="Detail View Note", content="Viewing this note")

        # Act
        # Request the detail view for the specific sticky note
        response = self.client.get(
            reverse("sticky_note_detail", args=[specific_note.pk]))

        # Assert
        # Confirmation of title of the 'specific_note'
        self.assertContains(response, "Detail View Note")

        # Confirm loading of page successfull
        self.assertEqual(response.status_code, 200)


class StickyNoteUpdateViewTests(TestCase):
    def test_update_sticky_note(self):
        # Arrange
        # Create a sticky note to be updated
        specific_note = StickyNote.objects.create(
            title="Old title and is to be updated",
            content="Old content and is to be updated")

        # Act
        # Send updated data to the update view
        response = self.client.post(
            reverse("sticky_note_update", args=[specific_note.pk]),
            {
                "title": "Updated title that has been updated",
                "content": "Updated content that has been updated",
                "is_pinned": False}
            )

        # Reload the object from the database
        specific_note.refresh_from_db()

        # Assert
        # Confirm the title of sticky note has been
        self.assertEqual(
            specific_note.title, "Updated title that has been updated")

        # Confirm user is redirecte back to the sticky note list page
        self.assertRedirects(response, reverse("sticky_note_list"))
